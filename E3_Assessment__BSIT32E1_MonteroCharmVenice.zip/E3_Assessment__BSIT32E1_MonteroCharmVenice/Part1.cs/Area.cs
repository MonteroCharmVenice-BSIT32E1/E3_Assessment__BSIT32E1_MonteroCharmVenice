using System;

namespace Area
{
    public interface AreaCalculator
    {
        double CalculateArea();
    }
    public class Triangle : AreaCalculator
    {
        private double baseLength;
        private double height;

    public Triangle(double b, double h)
        {
            baseLength = b;
            height = h;
        } 

    public double CalculateArea()
        {
            return 0.5 * baseLength * height;
        }
    }
    
    class Program
    {
    static void Main(string[] args)
        {
            
            Console.Write("Enter the base of the triangle: ");
            double baseLength = Convert.ToDouble(Console.ReadLine());


            Console.Write("Enter the height of the triangle: ");
            double height = Convert.ToDouble(Console.ReadLine());

        
            Triangle triangle = new Triangle(baseLength, height);

 
            double area = triangle.CalculateArea();

      
            Console.WriteLine($"The area of the triangle with base {baseLength} and height {height} is: {area}");
        }
    }
}
