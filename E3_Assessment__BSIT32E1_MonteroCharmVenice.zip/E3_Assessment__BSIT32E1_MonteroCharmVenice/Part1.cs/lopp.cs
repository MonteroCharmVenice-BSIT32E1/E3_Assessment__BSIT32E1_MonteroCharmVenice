using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Here are the numbers from 1 to 10 with their respective square roots:");
        Console.WriteLine(); // For Space Purpose only

        for (int i = 1; i <= 10; i++)
        {
            double squareRoot = Math.Sqrt(i);
            Console.WriteLine($"Number: {i}, Square Root: {squareRoot}");
        }
    }
}