using System;

class Program
{
    static void Main(string[] args)
    {
        int[] numbers = new int[5];

        //(n^2)
        for (int i = 0; i < numbers.Length; i++)
        {
            numbers[i] = (i + 1) * (i + 1); // Formula: n^2
        }

        Console.WriteLine("Array elements:");
        foreach (int num in numbers)
        {
            Console.WriteLine(num);
        }

        int largest = FindLargestElement(numbers);
        Console.WriteLine($"The largest element in the array is: {largest}");
    }

    static int FindLargestElement(int[] arr)
    {
        int max = arr[0]; 

        for (int i = 1; i < arr.Length; i++)
        {
            if (arr[i] > max)
            {
                max = arr[i];
            }
        }

        return max;
    }
}